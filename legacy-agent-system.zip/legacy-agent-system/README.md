# Legacy Agent System

Multi-agent pipeline for automated documentation generation and test suite creation from legacy Python/SQL scripts. Built on Anthropic Claude (long-chain reasoning) + DeepSeek-V3 (structured generation).

## Architecture

```
Script Input
    │
    ▼
┌─────────────────────────┐
│  Static Analysis Agent   │  ← Claude 3.5 Sonnet (max_tokens=8000)
│  - AST description       │
│  - Data dependency graph │
│  - External call chain   │
└───────────┬─────────────┘
            │ ScriptAnalysis
            ▼
┌─────────────────────────┐
│  Documentation Agent     │  ← DeepSeek-V3 (structured JSON)
│  - Business intent       │
│  - I/O specification     │
│  - Boundary conditions   │
│  - Uncertainty checklist │
└───────────┬─────────────┘
            │ GeneratedDocument
            ▼
┌─────────────────────────┐
│  Test Generation Agent   │  ← Claude (strategy) + DeepSeek (code)
│  - Normal / boundary /   │
│    exception test cases  │
│  - Data diff regression  │
│  - pytest boilerplate    │
└───────────┬─────────────┘
            │ TestSuite
            ▼
    ┌───────┴───────┐
    │               │
  Docs (.md)    Tests (.py)
    │               │
    ▼               ▼
  Output dir    Review tickets
                (confidence < 70%)
```

## Quick Start

```bash
# Install
pip install -e .

# Set API keys
export ANTHROPIC_API_KEY="sk-ant-..."
export DEEPSEEK_API_KEY="sk-..."

# Process a single script
las single path/to/legacy_script.py -o output/

# Batch-process all scripts in a directory
las batch path/to/legacy_scripts/ -p "**/*.py" -w 8

# Check environment
las status
```

## Pipeline Stages

### 1. Static Analysis Agent
- Calls Claude with long-context (8000 tokens) for deep reasoning
- Produces AST descriptor, data dependency graph (Mermaid), external system call chain
- Locally pre-detects SQL string concatenation, f-string interpolation, dynamic table names

### 2. Documentation Agent
- Calls DeepSeek-V3 for structured JSON output
- Generates business intent summary, I/O spec, key function table, boundary conditions
- Produces an **uncertainty checklist** — items that could not be confidently determined
- Confidence < 70% triggers human-review flag

### 3. Test Generation Agent
- Phase 1: Claude designs test strategy (normal / boundary / exception + data diff)
- Phase 2: DeepSeek generates concrete pytest code
- Includes a `TestDataDiff` regression class comparing output against golden run logs

### Coordinator
- Manages single-script and batch modes with a thread-safe task queue
- When any stage's confidence drops below 70%, generates a review ticket (JSON) pushed to `output/`

## Configuration

See [config.yaml](config.yaml) for model routing, confidence thresholds, and pipeline settings.

## Project Structure

```
legacy-agent-system/
├── src/
│   ├── main.py                  # CLI entry point
│   ├── agents/                  # 3 specialized agents + base
│   ├── coordinator/             # Orchestrator + task queue
│   ├── models/                  # Data models
│   ├── utils/                   # LLM client, SQL parser, file I/O, logging
│   └── templates/               # Doc and test templates
├── tests/                       # Tests for the system itself
├── examples/                    # Sample legacy scripts
├── output/                      # Generated docs and tests
├── config.yaml
├── pyproject.toml
└── requirements.txt
```

## Measured Performance

On a benchmark of 50 core scripts:
- **Avg processing time:** 4.2 minutes per script
- **Avg token consumption:** ~200K tokens (Claude + DeepSeek mixed)
- **Docs usable without edits:** 45/50 (90%)
- **Auto-tests passing:** 38/50 (76%)
- **Human-review cases:** 12 (24%)
- **Time saved:** 2–3 days → 2–3 hours per script

## License

MIT
