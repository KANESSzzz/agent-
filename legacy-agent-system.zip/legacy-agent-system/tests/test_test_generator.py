"""Tests for TestGeneratorAgent (classification & sanitization logic)."""

import pytest

from src.agents.test_generator import TestGeneratorAgent
from src.models.test_suite import TestCategory


class TestCaseClassification:
    def test_classify_normal_cases(self):
        strategy = """
NORMAL:
- test_valid_input: Should return a DataFrame with expected columns
- test_empty_data: Should handle empty gracefully
EXCEPTION:
- test_missing_column: Should raise KeyError
"""
        cases = TestGeneratorAgent._classify_cases(strategy, TestCategory.NORMAL)
        assert len(cases) >= 1
        assert any("valid_input" in c.name for c in cases)

    def test_classify_boundary_cases(self):
        strategy = """
BOUNDARY:
- test_max_rows: Large input
- test_null_values: NULL handling
"""
        cases = TestGeneratorAgent._classify_cases(strategy, TestCategory.BOUNDARY)
        assert len(cases) >= 1

    def test_classify_exception_cases(self):
        strategy = """
EXCEPTION:
- test_db_connection_failure: Mock connection error
"""
        cases = TestGeneratorAgent._classify_cases(strategy, TestCategory.EXCEPTION)
        assert len(cases) >= 1

    def test_empty_strategy(self):
        for cat in TestCategory:
            cases = TestGeneratorAgent._classify_cases("", cat)
            assert cases == []


class TestCodeSanitization:
    def test_strips_markdown_fences(self):
        raw = "```python\nimport pytest\ndef test_x(): pass\n```"
        clean = TestGeneratorAgent._sanitize_code(raw)
        assert "```" not in clean
        assert "import pytest" in clean

    def test_no_fences_passthrough(self):
        raw = "import pytest\ndef test_x(): pass\n"
        clean = TestGeneratorAgent._sanitize_code(raw)
        assert clean.strip() == raw.strip()


class TestTestSuiteModel:
    def test_default_suite_empty(self):
        from src.models.test_suite import TestSuite

        s = TestSuite(script_path="/x.py")
        assert s.normal_cases == []
        assert s.overall_confidence == 0.0

    def test_regression_config_defaults(self):
        from src.models.test_suite import RegressionTestConfig

        cfg = RegressionTestConfig()
        assert cfg.tolerance == 0.05
        assert cfg.diff_mode == "strict"
