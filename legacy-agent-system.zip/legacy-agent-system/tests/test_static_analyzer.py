"""Tests for the StaticAnalyzerAgent (offline, no LLM calls)."""

import pytest

from src.models.script_analysis import SQLPattern
from src.utils.sql_parser import SQLParser


SAMPLE_LEGACY_PY = '''
import pymysql
TABLE = "orders_daily"

def fetch(tbl: str, dt: str):
    sql = f"SELECT * FROM {tbl} WHERE date = '{dt}'"
    conn.execute(sql)
    return conn.fetchall()

def load(df):
    df.to_sql("report", engine, if_exists="append")
'''


class TestSQLParser:
    def test_detect_fstring_sql(self):
        extractions = SQLParser.extract_sql_strings(SAMPLE_LEGACY_PY)
        patterns = {e.pattern for e in extractions}
        assert SQLPattern.FSTRING in patterns

    def test_detect_raw_sql_execute(self):
        extractions = SQLParser.extract_sql_strings(SAMPLE_LEGACY_PY)
        assert any("execute" in e.raw_sql.lower() for e in extractions)

    def test_extract_table_names(self):
        names = SQLParser._extract_table_names("SELECT a FROM orders_daily JOIN users")
        assert "orders_daily" in names
        assert "users" in names

    def test_detect_dynamic_tables(self):
        dynamic = SQLParser.detect_dynamic_tables(SAMPLE_LEGACY_PY)
        # TABLE is a variable — but name lacks table/tbl keyword, so might not match
        assert isinstance(dynamic, list)

    def test_empty_source(self):
        assert SQLParser.extract_sql_strings("") == []

    def test_no_sql_source(self):
        src = "print('hello')\nx = 1 + 2\n"
        assert SQLParser.extract_sql_strings(src) == []
