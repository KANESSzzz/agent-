"""Tests for the legacy-agent-system itself."""
