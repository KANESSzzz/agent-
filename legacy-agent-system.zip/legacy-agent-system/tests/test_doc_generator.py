"""Tests for DocGeneratorAgent (rendering & confidence logic)."""

import pytest

from src.models.documentation import (
    BoundaryCondition,
    GeneratedDocument,
    UncertaintyItem,
)
from src.models.script_analysis import (
    ASTDescriptor,
    DataDependencyGraph,
    ScriptAnalysis,
    SQLPattern,
)


@pytest.fixture
def minimal_analysis():
    return ScriptAnalysis(
        file_path="/fake/etl.py",
        ast=ASTDescriptor(
            functions=[
                {"name": "fetch", "params": ["tbl", "dt"], "returns": "DataFrame"}
            ],
            imports=["pandas", "sqlalchemy"],
        ),
        data_deps=DataDependencyGraph(
            input_tables=["user_events"],
            output_tables=["daily_user_activity"],
            sql_patterns_detected=[SQLPattern.FSTRING],
        ),
    )


class TestDocRendering:
    def test_markdown_includes_business_intent(self):
        doc = GeneratedDocument(
            file_path="/fake/etl_DOC.md",
            script_path="/fake/etl.py",
            business_intent="Aggregate user events per day.",
            overall_confidence=0.85,
        )
        from src.agents.doc_generator import DocGeneratorAgent

        md = DocGeneratorAgent._render_markdown(doc)
        assert "Aggregate user events per day" in md
        assert "85%" in md

    def test_markdown_includes_boundary_table(self):
        doc = GeneratedDocument(
            file_path="/fake/etl_DOC.md",
            script_path="/fake/etl.py",
            boundary_conditions=[
                BoundaryCondition("Empty input", "Return empty DataFrame", "medium")
            ],
        )
        from src.agents.doc_generator import DocGeneratorAgent

        md = DocGeneratorAgent._render_markdown(doc)
        assert "Empty input" in md
        assert "medium" in md

    def test_uncertainty_triggers_review(self):
        doc = GeneratedDocument(
            file_path="/fake/etl_DOC.md",
            script_path="/fake/etl.py",
            uncertainty_checklist=[
                UncertaintyItem(
                    category="data_caliber",
                    description="Cannot determine aggregation window",
                    confidence=0.4,
                )
            ],
            overall_confidence=0.65,
        )
        # Needs review: overall < 0.70
        assert doc.overall_confidence < 0.70


class TestDocRenderEdgeCases:
    def test_empty_doc_renders(self):
        from src.agents.doc_generator import DocGeneratorAgent

        doc = GeneratedDocument(file_path="/x.md", script_path="/x.py")
        md = DocGeneratorAgent._render_markdown(doc)
        assert "# Script Documentation" in md

    def test_fallback_parse_produces_uncertainty(self):
        from src.agents.doc_generator import DocGeneratorAgent

        parsed = DocGeneratorAgent._fallback_parse("garbled output")
        assert len(parsed["uncertainty_checklist"]) == 1
        assert parsed["uncertainty_checklist"][0]["confidence"] == 0.1
