"""CLI entry point for the Legacy Agent System.

Usage:
    python -m src.main single path/to/script.py --output ./output
    python -m src.main batch path/to/scripts/ --pattern "**/*.py" --workers 4
    python -m src.main status
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from .coordinator.orchestrator import Orchestrator
from .utils.logger import get_logger

logger = get_logger("cli")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Legacy Agent System — multi-agent documentation & test generation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  las single scripts/etl_orders.py -o output/
  las batch legacy_scripts/ -p "**/*.py" -w 8
  las batch . -p "**/*.sql" --dry-run
        """,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # ---- single ----
    p_single = sub.add_parser("single", help="Process a single script")
    p_single.add_argument("script", help="Path to Python/SQL file")
    p_single.add_argument("-o", "--output", default="./output", help="Output directory")
    p_single.add_argument(
        "--confidence", type=float, default=0.70, help="Low-confidence threshold"
    )

    # ---- batch ----
    p_batch = sub.add_parser("batch", help="Process all scripts in a directory")
    p_batch.add_argument("directory", help="Directory containing legacy scripts")
    p_batch.add_argument("-p", "--pattern", default="**/*.py", help="Glob pattern")
    p_batch.add_argument("-o", "--output", default="./output", help="Output directory")
    p_batch.add_argument("-w", "--workers", type=int, default=4, help="Max parallel workers")
    p_batch.add_argument(
        "--confidence", type=float, default=0.70, help="Low-confidence threshold"
    )

    # ---- status ----
    sub.add_parser("status", help="Show environment status")

    return parser.parse_args(argv)


def cmd_single(args: argparse.Namespace) -> int:
    script = Path(args.script).resolve()
    if not script.exists():
        logger.error("File not found: %s", script)
        return 1
    orch = Orchestrator(
        output_dir=args.output,
        low_confidence_threshold=args.confidence,
    )
    result = orch.run_single(str(script))
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if orch.review_tickets:
        print(f"\n⚠  {len(orch.review_tickets)} review ticket(s) generated:")
        for t in orch.review_tickets:
            print(f"   - {t['script_path']} (priority={t['priority']})")
    return 0 if result.get("status") == "completed" else 1


def cmd_batch(args: argparse.Namespace) -> int:
    directory = Path(args.directory).resolve()
    if not directory.is_dir():
        logger.error("Directory not found: %s", directory)
        return 1
    orch = Orchestrator(
        output_dir=args.output,
        max_workers=args.workers,
        low_confidence_threshold=args.confidence,
    )
    results = orch.run_batch(str(directory), pattern=args.pattern)
    summary = {
        "total": len(results),
        "completed": sum(1 for r in results if r.get("status") == "completed"),
        "failed": sum(1 for r in results if r.get("status") == "failed"),
        "needs_review": sum(1 for r in results if r.get("needs_human_review")),
        "review_tickets": len(orch.review_tickets),
    }
    print(json.dumps(summary, indent=2))
    summary_path = Path(args.output) / "batch_summary.json"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(
        json.dumps({"summary": summary, "results": results}, indent=2, ensure_ascii=False)
    )
    if orch.review_tickets:
        print(f"\n⚠  {len(orch.review_tickets)} review ticket(s) generated.")
    return 0


def cmd_status() -> int:
    print("Legacy Agent System v1.0.0")
    print(f"  Python:        {sys.version}")
    print(f"  Working dir:   {os.getcwd()}")
    print(f"  ANTHROPIC_KEY: {'set' if os.getenv('ANTHROPIC_API_KEY') else 'missing'}")
    print(f"  DEEPSEEK_KEY:  {'set' if os.getenv('DEEPSEEK_API_KEY') else 'missing'}")
    return 0


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.command == "single":
        return cmd_single(args)
    elif args.command == "batch":
        return cmd_batch(args)
    elif args.command == "status":
        return cmd_status()
    return 0


if __name__ == "__main__":
    sys.exit(main())
