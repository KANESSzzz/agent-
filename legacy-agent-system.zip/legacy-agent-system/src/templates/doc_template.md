# Script Documentation: `{script_path}`

> **Overall confidence:** {confidence}
> **Needs human review:** {needs_review}

---

## Business Intent

{business_intent}

---

## Input / Output Specification

{input_output_spec}

---

## Key Functions

| Function | Role | Side Effects |
|----------|------|-------------|
{key_functions_table}

---

## Boundary Conditions

| Condition | Expected Behavior | Severity |
|-----------|------------------|----------|
{boundary_conditions_table}

---

## Uncertainty Checklist

{uncertainty_checklist}

---

{additional_sections}
