"""Coordinator Agent — manages the full 3-agent pipeline.

Orchestrates:
  1. StaticAnalyzerAgent → ScriptAnalysis
  2. DocGeneratorAgent → GeneratedDocument
  3. TestGeneratorAgent → TestSuite

Handles single-script and batch modes. When DocGenerator or TestGenerator
confidence drops below 70%, the task is flagged as "needs human review" and
an uncertainty ticket is produced.
"""

from __future__ import annotations

import json
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

from ..agents.static_analyzer import StaticAnalyzerAgent
from ..agents.doc_generator import DocGeneratorAgent
from ..agents.test_generator import TestGeneratorAgent
from ..models.documentation import GeneratedDocument
from ..models.script_analysis import ScriptAnalysis
from ..models.test_suite import TestSuite
from ..utils.file_handler import FileHandler
from ..utils.llm_client import LLMClient
from ..utils.logger import get_logger
from .task_queue import Task, TaskQueue, TaskStatus

logger = get_logger("orchestrator")


class Orchestrator:
    """Top-level coordinator for the legacy analysis pipeline.

    Usage:
        orch = Orchestrator(output_dir="./output")
        results = orch.run_single("/path/to/script.py")
        # or
        results = orch.run_batch("/path/to/scripts/", pattern="**/*.py")
    """

    def __init__(
        self,
        output_dir: str = "./output",
        max_workers: int = 4,
        low_confidence_threshold: float = 0.70,
        anthropic_api_key: str = "",
        deepseek_api_key: str = "",
    ):
        self.output_dir = Path(output_dir).resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.max_workers = max_workers
        self.low_confidence_threshold = low_confidence_threshold
        self.llm = LLMClient(
            anthropic_api_key=anthropic_api_key,
            deepseek_api_key=deepseek_api_key,
        )
        self.file_handler = FileHandler(str(self.output_dir))
        self.task_queue = TaskQueue(max_workers=max_workers)
        self._review_tickets: list[dict] = []

        # Agent instances
        self.analyzer = StaticAnalyzerAgent(llm=self.llm)
        self.doc_gen = DocGeneratorAgent(llm=self.llm)
        self.test_gen = TestGeneratorAgent(llm=self.llm)

        # Override confidence thresholds
        self.doc_gen.low_confidence_threshold = low_confidence_threshold
        self.test_gen.low_confidence_threshold = low_confidence_threshold

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def run_single(self, script_path: str) -> dict:
        """Process a single script through the full pipeline."""
        source = FileHandler.read_file(script_path)
        return self._process_script(script_path, source)

    def run_batch(self, script_dir: str, pattern: str = "**/*.py") -> list[dict]:
        """Process all matching scripts in a directory in parallel."""
        self.file_handler.base_dir = Path(script_dir).resolve()
        scripts = self.file_handler.discover_scripts([pattern])
        logger.info("Batch mode: discovered %d scripts", len(scripts))
        results: list[dict] = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(self._process_script, s.path, s.source): s.path
                for s in scripts
            }
            for future in as_completed(futures):
                path = futures[future]
                try:
                    result = future.result()
                    results.append(result)
                except Exception as exc:
                    logger.error("Batch failure for %s: %s", path, exc)
                    results.append({"file_path": path, "status": "failed", "error": str(exc)})
        return results

    # ------------------------------------------------------------------
    # Core pipeline
    # ------------------------------------------------------------------
    def _process_script(self, script_path: str, source: str) -> dict:
        start = time.perf_counter()
        result: dict = {"file_path": script_path, "stages": {}}
        try:
            # Stage 1: Static Analysis (Claude reasoning)
            analysis = self.analyzer.execute(source, file_path=script_path)
            result["stages"]["analysis"] = {
                "duration_ms": analysis.analysis_duration_ms,
                "tokens_in": analysis.raw_prompt_tokens,
                "tokens_out": analysis.raw_completion_tokens,
                "functions_found": len(analysis.ast.functions),
                "external_calls": len(analysis.external_calls),
            }

            # Stage 2: Documentation (DeepSeek structured)
            doc = self.doc_gen.execute(analysis, source=source)
            doc_path = self._write_doc_output(script_path, doc)
            result["stages"]["documentation"] = {
                "confidence": doc.overall_confidence,
                "needs_review": doc.needs_human_review,
                "uncertainties": len(doc.uncertainty_checklist),
                "output_path": doc_path,
            }

            # Stage 3: Test generation (Claude reasoning + DeepSeek code)
            golden_log = self._find_golden_log(script_path)
            test_suite = self.test_gen.execute(
                analysis, doc, source=source, golden_log_path=golden_log
            )
            test_path = self._write_test_output(script_path, test_suite)
            result["stages"]["testing"] = {
                "confidence": test_suite.overall_confidence,
                "test_count": len(test_suite.normal_cases)
                + len(test_suite.exception_cases)
                + len(test_suite.boundary_cases),
                "output_path": test_path,
            }

            # Review-ticket generation for low-confidence stages
            self._maybe_create_review_ticket(script_path, analysis, doc, test_suite)

            result["status"] = "completed"
            result["total_duration_ms"] = (time.perf_counter() - start) * 1000
            result["needs_human_review"] = doc.needs_human_review or self._test_needs_review(
                test_suite
            )
        except Exception as exc:
            logger.error("Pipeline failed for %s: %s", script_path, exc, exc_info=True)
            result["status"] = "failed"
            result["error"] = str(exc)
        return result

    # ------------------------------------------------------------------
    # Review ticket system
    # ------------------------------------------------------------------
    def _maybe_create_review_ticket(
        self,
        script_path: str,
        analysis: ScriptAnalysis,
        doc: GeneratedDocument,
        test_suite: TestSuite,
    ) -> None:
        """Generate a review ticket when any stage falls below confidence threshold."""
        if not doc.needs_human_review and not self._test_needs_review(test_suite):
            return
        ticket = {
            "id": str(uuid.uuid4())[:8],
            "script_path": script_path,
            "doc_confidence": doc.overall_confidence,
            "test_confidence": test_suite.overall_confidence,
            "uncertainties": [
                {
                    "category": u.category,
                    "description": u.description,
                    "snippet": u.context_snippet[:200],
                    "resolution": u.suggested_resolution,
                    "confidence": u.confidence,
                }
                for u in doc.uncertainty_checklist
            ],
            "functions": [
                f.get("name", "?") for f in analysis.ast.functions
            ],
            "suggested_reviewers": ["data-team", "original-author"],
            "priority": "high" if doc.overall_confidence < 0.5 else "medium",
        }
        self._review_tickets.append(ticket)
        ticket_path = self.output_dir / f"review_ticket_{ticket['id']}.json"
        ticket_path.write_text(
            json.dumps(ticket, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        logger.warning(
            "Review ticket %s created for %s (doc_conf=%.0f%%, test_conf=%.0f%%)",
            ticket["id"],
            script_path,
            doc.overall_confidence * 100,
            test_suite.overall_confidence * 100,
        )

    @property
    def review_tickets(self) -> list[dict]:
        return list(self._review_tickets)

    # ------------------------------------------------------------------
    # I/O helpers
    # ------------------------------------------------------------------
    def _write_doc_output(self, script_path: str, doc: GeneratedDocument) -> str:
        out_name = Path(script_path).stem + "_DOC.md"
        out_path = self.output_dir / out_name
        FileHandler.write_markdown(str(out_path), doc.markdown_body)
        return str(out_path)

    def _write_test_output(self, script_path: str, suite: TestSuite) -> str:
        out_name = Path(script_path).stem + "_test.py"
        out_path = self.output_dir / out_name
        FileHandler.write_python(str(out_path), suite.generated_code)
        return str(out_path)

    @staticmethod
    def _find_golden_log(script_path: str) -> str:
        """Look for a matching log file next to the script."""
        base = Path(script_path).with_suffix("")
        for ext in (".log", ".out", ".csv", "_sample.log"):
            candidate = Path(str(base) + ext)
            if candidate.exists():
                return str(candidate)
        return ""

    @staticmethod
    def _test_needs_review(suite: TestSuite) -> bool:
        return suite.overall_confidence < 0.70
