"""Task queue for single-script and batch processing modes."""

from __future__ import annotations

import threading
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Optional

from ..utils.logger import get_logger

logger = get_logger("task_queue")


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    NEEDS_REVIEW = "needs_review"


@dataclass
class Task:
    id: str
    file_path: str
    status: TaskStatus = TaskStatus.PENDING
    result: dict = field(default_factory=dict)
    error: str = ""
    assigned_worker: str = ""
    created_at: str = ""
    completed_at: str = ""

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "file_path": self.file_path,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
        }


class TaskQueue:
    """Thread-safe queue managing script processing tasks.

    Supports single-script mode (process one) and batch mode (process a directory).
    """

    def __init__(self, max_workers: int = 4):
        self._queue: deque[Task] = deque()
        self._lock = threading.Lock()
        self._max_workers = max_workers
        self._semaphore = threading.Semaphore(max_workers)
        self._results: dict[str, Task] = {}
        self._on_complete: Optional[Callable[[Task], None]] = None

    # ------------------------------------------------------------------
    def enqueue(self, task: Task) -> None:
        with self._lock:
            self._queue.append(task)
            self._results[task.id] = task
        logger.debug("Enqueued task %s for %s", task.id, task.file_path)

    def enqueue_batch(self, file_paths: list[str]) -> list[Task]:
        tasks: list[Task] = []
        for i, fp in enumerate(file_paths):
            task = Task(id=f"task-{i:04d}", file_path=fp)
            tasks.append(task)
            self.enqueue(task)
        logger.info("Enqueued %d tasks in batch", len(tasks))
        return tasks

    def dequeue(self) -> Optional[Task]:
        with self._lock:
            if self._queue:
                return self._queue.popleft()
            return None

    # ------------------------------------------------------------------
    def acquire_slot(self) -> bool:
        return self._semaphore.acquire(blocking=False)

    def release_slot(self) -> None:
        self._semaphore.release()

    # ------------------------------------------------------------------
    def mark_complete(self, task_id: str, result: dict) -> None:
        with self._lock:
            if task_id in self._results:
                self._results[task_id].status = TaskStatus.COMPLETED
                self._results[task_id].result = result

    def mark_failed(self, task_id: str, error: str) -> None:
        with self._lock:
            if task_id in self._results:
                self._results[task_id].status = TaskStatus.FAILED
                self._results[task_id].error = error

    def mark_needs_review(self, task_id: str, reason: str = "") -> None:
        with self._lock:
            if task_id in self._results:
                self._results[task_id].status = TaskStatus.NEEDS_REVIEW
                self._results[task_id].error = reason

    # ------------------------------------------------------------------
    @property
    def pending_count(self) -> int:
        with self._lock:
            return len(self._queue)

    @property
    def results(self) -> dict[str, Task]:
        with self._lock:
            return dict(self._results)

    def summary(self) -> dict:
        with self._lock:
            counts = {s: 0 for s in TaskStatus}
            for t in self._results.values():
                counts[t.status] += 1
            return {"total": len(self._results), **{k.value: v for k, v in counts.items()}}

    # ------------------------------------------------------------------
    def set_on_complete(self, callback: Callable[[Task], None]) -> None:
        self._on_complete = callback

    def notify_complete(self, task: Task) -> None:
        if self._on_complete:
            self._on_complete(task)
