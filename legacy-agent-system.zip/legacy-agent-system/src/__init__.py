"""Legacy Agent System — Multi-Agent Documentation & Test Generation."""

__version__ = "1.0.0"
