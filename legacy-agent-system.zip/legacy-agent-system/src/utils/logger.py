"""Structured logger for the legacy agent system."""

from __future__ import annotations

import logging
import sys
from datetime import datetime
from typing import Optional

LOGGER_NAME = "legacy_agent"

_initialized = False


def get_logger(name: Optional[str] = None) -> logging.Logger:
    global _initialized
    logger = logging.getLogger(name or LOGGER_NAME)
    if not _initialized:
        logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.DEBUG)
        fmt = logging.Formatter(
            "[%(asctime)s] %(levelname)-7s %(name)s | %(message)s",
            datefmt="%H:%M:%S",
        )
        handler.setFormatter(fmt)
        logger.addHandler(handler)
        _initialized = True
    return logger
