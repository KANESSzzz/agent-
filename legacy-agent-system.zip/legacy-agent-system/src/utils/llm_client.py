"""Multi-provider LLM client with model routing between Claude and DeepSeek.

Routes long-chain reasoning tasks to Claude 3.5 Sonnet (max_tokens=8000)
and structured generation tasks to DeepSeek-V3 for cost efficiency.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any, Optional

from .logger import get_logger

logger = get_logger(__name__)


@dataclass
class ModelConfig:
    provider: str  # "claude" | "deepseek"
    model_id: str
    max_tokens: int = 4096
    temperature: float = 0.3
    api_key_env: str = ""


class ModelRouter:
    """Selects the appropriate model based on task type.

    Reasoning tasks (analysis, comprehension) -> Claude
    Structured generation (docs, test code) -> DeepSeek
    """

    CLAUDE_MODEL = "claude-3-5-sonnet-20241022"
    DEEPSEEK_MODEL = "deepseek-chat"

    @classmethod
    def for_reasoning(cls, max_tokens: int = 8000) -> ModelConfig:
        return ModelConfig(
            provider="claude",
            model_id=cls.CLAUDE_MODEL,
            max_tokens=max_tokens,
            temperature=0.2,
            api_key_env="ANTHROPIC_API_KEY",
        )

    @classmethod
    def for_structured(cls) -> ModelConfig:
        return ModelConfig(
            provider="deepseek",
            model_id=cls.DEEPSEEK_MODEL,
            max_tokens=4096,
            temperature=0.1,
            api_key_env="DEEPSEEK_API_KEY",
        )


class LLMClient:
    """Unified client for both Anthropic Claude and DeepSeek APIs."""

    def __init__(self, anthropic_api_key: str = "", deepseek_api_key: str = ""):
        self.anthropic_key = anthropic_api_key or os.getenv("ANTHROPIC_API_KEY", "")
        self.deepseek_key = deepseek_api_key or os.getenv("DEEPSEEK_API_KEY", "")
        self._anthropic_client = None
        self._openai_client = None  # DeepSeek uses OpenAI-compatible API

    # ------------------------------------------------------------------
    # Claude (long-chain reasoning)
    # ------------------------------------------------------------------
    def _get_anthropic(self):
        if self._anthropic_client is None:
            import anthropic

            self._anthropic_client = anthropic.Anthropic(api_key=self.anthropic_key)
        return self._anthropic_client

    def claude_complete(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 8000,
        temperature: float = 0.2,
    ) -> tuple[str, int, int]:
        """Call Claude with long-context reasoning. Returns (text, input_tokens, output_tokens)."""
        client = self._get_anthropic()
        start = time.perf_counter()
        resp = client.messages.create(
            model=ModelRouter.CLAUDE_MODEL,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )
        elapsed = time.perf_counter() - start
        text = resp.content[0].text if resp.content else ""
        in_tok = resp.usage.input_tokens
        out_tok = resp.usage.output_tokens
        logger.info(
            "Claude call: %d input tokens, %d output tokens, %.1fs",
            in_tok,
            out_tok,
            elapsed,
        )
        return text, in_tok, out_tok

    # ------------------------------------------------------------------
    # DeepSeek (structured generation via OpenAI-compatible API)
    # ------------------------------------------------------------------
    def _get_openai(self):
        if self._openai_client is None:
            from openai import OpenAI

            self._openai_client = OpenAI(
                api_key=self.deepseek_key,
                base_url="https://api.deepseek.com",
            )
        return self._openai_client

    def deepseek_complete(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 4096,
        temperature: float = 0.1,
        response_format: Optional[dict] = None,
    ) -> tuple[str, int, int]:
        """Call DeepSeek for structured output. Returns (text, input_tokens, output_tokens)."""
        client = self._get_openai()
        start = time.perf_counter()
        kwargs: dict[str, Any] = {
            "model": ModelRouter.DEEPSEEK_MODEL,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }
        if response_format:
            kwargs["response_format"] = response_format
        resp = client.chat.completions.create(**kwargs)
        elapsed = time.perf_counter() - start
        text = resp.choices[0].message.content or ""
        in_tok = resp.usage.prompt_tokens if resp.usage else 0
        out_tok = resp.usage.completion_tokens if resp.usage else 0
        logger.info(
            "DeepSeek call: %d input tokens, %d output tokens, %.1fs",
            in_tok,
            out_tok,
            elapsed,
        )
        return text, in_tok, out_tok

    # ------------------------------------------------------------------
    # Convenience: structured JSON extraction
    # ------------------------------------------------------------------
    def deepseek_json(
        self, system_prompt: str, user_prompt: str, max_tokens: int = 4096
    ) -> dict:
        """Call DeepSeek and parse response as JSON."""
        text, _, _ = self.deepseek_complete(
            system_prompt, user_prompt, max_tokens=max_tokens
        )
        # Strip markdown code fences if present
        text = text.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1]
            if text.endswith("```"):
                text = text[:-3]
        return json.loads(text.strip())
