"""SQL string analysis utilities.

Handles detection of SQL string concatenation patterns, dynamic table names,
f-string interpolation in SQL, and other common legacy patterns.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..models.script_analysis import SQLPattern


@dataclass
class SQLExtraction:
    raw_sql: str
    pattern: SQLPattern
    tables_referenced: list[str] = field(default_factory=list)
    is_dynamic_table: bool = False
    line_range: tuple[int, int] = (0, 0)


class SQLParser:
    """Extracts and classifies SQL patterns from Python source code."""

    # Common SQL keyword prefixes that signal embedded SQL
    SQL_KEYWORDS = re.compile(
        r"\b(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|ALTER|MERGE|WITH|FROM|JOIN|WHERE|GROUP\s+BY|ORDER\s+BY|HAVING|UNION|EXCEPT|INTERSECT)\b",
        re.IGNORECASE,
    )

    STRING_FORMAT_PATTERNS = [
        (SQLPattern.FSTRING, re.compile(r'f["\'].*?(SELECT|INSERT|UPDATE|DELETE).*?["\']', re.IGNORECASE | re.DOTALL)),
        (SQLPattern.STRING_CONCAT, re.compile(r'["\'].*?(SELECT|INSERT|UPDATE|DELETE).*?["\']\s*\+', re.IGNORECASE | re.DOTALL)),
        (SQLPattern.RAW_SQL, re.compile(r'(?:execute|cursor\.execute|pd\.read_sql|read_sql_query)\s*\(', re.IGNORECASE)),
        (SQLPattern.STORED_PROC, re.compile(r'(?:callproc|call\s+procedure|EXEC\s+sp_)', re.IGNORECASE)),
    ]

    @staticmethod
    def extract_sql_strings(source: str) -> list[SQLExtraction]:
        """Walk source lines and extract SQL-bearing fragments."""
        results: list[SQLExtraction] = []
        lines = source.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            if SQLParser.SQL_KEYWORDS.search(line):
                for pattern_type, regex in SQLParser.STRING_FORMAT_PATTERNS:
                    if regex.search(line):
                        tables = SQLParser._extract_table_names(line)
                        ext = SQLExtraction(
                            raw_sql=line.strip(),
                            pattern=pattern_type,
                            tables_referenced=tables,
                            is_dynamic_table=any(
                                kw in line.lower()
                                for kw in ["format(", "f\"", "f'", "%s", "{table", "tablename"]
                            ),
                            line_range=(i + 1, i + 1),
                        )
                        results.append(ext)
                        break
            i += 1
        return results

    @staticmethod
    def _extract_table_names(sql_text: str) -> list[str]:
        """Naive table-name extraction — refined by the LLM pass later."""
        matches = re.findall(
            r'(?:FROM|JOIN|INTO|UPDATE|TABLE)\s+([`"\[]?[\w]+[`"\]]?)',
            sql_text,
            re.IGNORECASE,
        )
        return [m.strip('`"[]') for m in matches]

    @staticmethod
    def detect_dynamic_tables(source: str) -> list[str]:
        """Identify variables that appear to hold table names."""
        pattern = re.compile(r'(\w+)\s*=\s*[\'"](\w+)[\'"]', re.IGNORECASE)
        candidates: list[str] = []
        for match in pattern.finditer(source):
            var_name = match.group(1)
            if any(
                kw in var_name.lower()
                for kw in ["table", "tbl", "tablename", "table_name"]
            ):
                candidates.append(match.group(2))
        return candidates

    @staticmethod
    def extract_subqueries(source: str) -> list[str]:
        """Extract nested SELECT statements."""
        # Simplified: capture lines with nested SELECT inside parentheses
        pattern = re.compile(
            r'\(\s*SELECT\s+.+?\s+FROM\s+.+?\s*\)',
            re.IGNORECASE | re.DOTALL,
        )
        return pattern.findall(source)
