"""File I/O helper: read scripts, write outputs, collect logs."""

from __future__ import annotations

import glob as _glob
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class ScriptFile:
    path: str
    name: str
    source: str
    loc: int
    language: str
    has_sql: bool = False


class FileHandler:
    """Handles file discovery, reading, and output writing."""

    SUPPORTED_EXTENSIONS = {".py", ".sql"}

    def __init__(self, base_dir: str):
        self.base_dir = Path(base_dir).resolve()

    def discover_scripts(
        self, patterns: Optional[list[str]] = None
    ) -> list[ScriptFile]:
        """Find all supported script files in base_dir."""
        if patterns is None:
            patterns = ["**/*.py", "**/*.sql"]
        results: list[ScriptFile] = []
        seen: set[str] = set()
        for pat in patterns:
            for path in self.base_dir.glob(pat):
                abs_path = str(path.resolve())
                if abs_path in seen:
                    continue
                seen.add(abs_path)
                try:
                    source = path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    source = path.read_text(encoding="latin-1")
                loc = len(source.splitlines())
                lang = path.suffix.lstrip(".")
                has_sql = lang == "sql" or (
                    lang == "py" and ("SELECT" in source.upper() or "execute(" in source)
                )
                results.append(
                    ScriptFile(
                        path=abs_path,
                        name=path.name,
                        source=source,
                        loc=loc,
                        language=lang,
                        has_sql=has_sql,
                    )
                )
        return sorted(results, key=lambda s: s.path)

    @staticmethod
    def read_file(path: str) -> str:
        return Path(path).read_text(encoding="utf-8")

    @staticmethod
    def write_markdown(path: str, content: str) -> None:
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(content, encoding="utf-8")

    @staticmethod
    def write_json(path: str, data: dict) -> None:
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    @staticmethod
    def write_python(path: str, code: str) -> None:
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(code, encoding="utf-8")

    @staticmethod
    def find_logs(script_dir: str) -> list[str]:
        """Find sample run logs near scripts (common naming conventions)."""
        base = Path(script_dir)
        candidates = list(base.rglob("*.log")) + list(base.rglob("*.out"))
        return [str(c.resolve()) for c in candidates]
