"""Data models for generated documentation."""

from dataclasses import dataclass, field


@dataclass
class BoundaryCondition:
    condition: str
    expected_behavior: str
    severity: str  # "low", "medium", "high", "critical"


@dataclass
class UncertaintyItem:
    category: str  # "data_caliber", "business_rule", "system_dependency", "other"
    description: str
    context_snippet: str = ""
    suggested_resolution: str = ""
    confidence: float = 0.0  # 0.0 – 1.0


@dataclass
class DocSection:
    title: str
    content: str
    level: int = 2  # markdown heading level


@dataclass
class GeneratedDocument:
    file_path: str
    script_path: str
    business_intent: str = ""
    input_output_spec: str = ""
    key_functions: list[dict] = field(default_factory=list)
    boundary_conditions: list[BoundaryCondition] = field(default_factory=list)
    uncertainty_checklist: list[UncertaintyItem] = field(default_factory=list)
    sections: list[DocSection] = field(default_factory=list)
    overall_confidence: float = 0.0
    needs_human_review: bool = False
    markdown_body: str = ""
