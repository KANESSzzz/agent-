"""Data models for generated test suites."""

from dataclasses import dataclass, field
from enum import Enum


class TestCategory(str, Enum):
    NORMAL = "normal"
    EXCEPTION = "exception"
    BOUNDARY = "boundary"


@dataclass
class TestCase:
    name: str
    category: TestCategory
    description: str
    input_data: dict = field(default_factory=dict)
    expected_pattern: str = ""  # regex or type signature for output validation
    expected_exception: str = ""
    code: str = ""


@dataclass
class RegressionTestConfig:
    golden_run_log_path: str = ""
    tolerance: float = 0.05
    compare_columns: list[str] = field(default_factory=list)
    ignore_order: bool = True
    diff_mode: str = "strict"  # "strict" | "relaxed" | "schema_only"


@dataclass
class DiffReport:
    total_rows: int = 0
    matched_rows: int = 0
    added_rows: int = 0
    removed_rows: int = 0
    changed_rows: int = 0
    column_diffs: dict = field(default_factory=dict)
    passed: bool = False
    summary: str = ""


@dataclass
class TestSuite:
    script_path: str
    test_file_path: str = ""
    normal_cases: list[TestCase] = field(default_factory=list)
    exception_cases: list[TestCase] = field(default_factory=list)
    boundary_cases: list[TestCase] = field(default_factory=list)
    regression_config: RegressionTestConfig = field(default_factory=RegressionTestConfig)
    generated_code: str = ""
    diff_report: DiffReport = field(default_factory=DiffReport)
    overall_confidence: float = 0.0
