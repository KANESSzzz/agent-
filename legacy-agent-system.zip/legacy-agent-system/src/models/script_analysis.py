"""Data models for static script analysis results."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class SQLPattern(str, Enum):
    STRING_CONCAT = "string_concat"
    RAW_SQL = "raw_sql"
    ORM_BUILDER = "orm_builder"
    FSTRING = "fstring"
    STORED_PROC = "stored_proc"
    UNKNOWN = "unknown"


@dataclass
class ASTDescriptor:
    functions: list[dict] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    classes: list[dict] = field(default_factory=list)
    global_vars: list[str] = field(default_factory=list)
    decorators: list[str] = field(default_factory=list)
    control_flow_complexity: int = 0
    raw_ast_json: Optional[str] = None


@dataclass
class ExternalCall:
    name: str
    call_type: str  # "api", "database", "file_io", "env", "subprocess"
    pattern: str
    parameters: list[str] = field(default_factory=list)
    is_dynamic: bool = False


@dataclass
class DataDependencyGraph:
    nodes: list[dict] = field(default_factory=list)
    edges: list[dict] = field(default_factory=list)
    input_tables: list[str] = field(default_factory=list)
    output_tables: list[str] = field(default_factory=list)
    intermediate_views: list[str] = field(default_factory=list)
    sql_patterns_detected: list[SQLPattern] = field(default_factory=list)
    dynamic_table_references: list[str] = field(default_factory=list)
    mermaid_diagram: Optional[str] = None


@dataclass
class ScriptAnalysis:
    file_path: str
    ast: ASTDescriptor = field(default_factory=ASTDescriptor)
    data_deps: DataDependencyGraph = field(default_factory=DataDependencyGraph)
    external_calls: list[ExternalCall] = field(default_factory=list)
    estimated_loc: int = 0
    language: str = "python"
    raw_prompt_tokens: int = 0
    raw_completion_tokens: int = 0
    llm_model_used: str = ""
    analysis_duration_ms: float = 0.0
