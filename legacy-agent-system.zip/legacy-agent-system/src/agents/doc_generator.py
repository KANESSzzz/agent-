"""Documentation Agent — generates Markdown docs from analysis output.

Uses DeepSeek-V3 for structured generation. Produces:
- Business intent summary
- Input/output format specification
- Key function descriptions
- Boundary condition analysis
- Uncertainty checklist (flagged for human review when confidence < 70%)
"""

from __future__ import annotations

from ..models.documentation import (
    BoundaryCondition,
    DocSection,
    GeneratedDocument,
    UncertaintyItem,
)
from ..models.script_analysis import ScriptAnalysis
from .base import BaseAgent


class DocGeneratorAgent(BaseAgent):
    """Generates structured Markdown documentation from script analysis."""

    agent_name = "doc_generator"

    @property
    def system_prompt(self) -> str:
        return (
            "You are a technical documentation writer specializing in legacy data-processing systems. "
            "Given a static analysis of a Python/SQL script, produce comprehensive Markdown documentation. "
            "Focus on business intent, data flow, and operational considerations. "
            "When the analysis is ambiguous, explicitly flag uncertainties in a checklist with confidence scores. "
            "Output ONLY valid JSON conforming to the requested schema — no markdown fences, no commentary."
        )

    # ------------------------------------------------------------------
    def execute(
        self,
        analysis: ScriptAnalysis,
        source: str = "",
        **kwargs,
    ) -> GeneratedDocument:
        self.logger.info("Generating docs for %s", analysis.file_path)

        user_prompt = self._build_prompt(analysis, source)
        try:
            parsed = self.llm.deepseek_json(
                system_prompt=self.system_prompt, user_prompt=user_prompt
            )
        except Exception:
            self.logger.warning(
                "DeepSeek JSON parse failed, falling back to structured text"
            )
            text = self._structured_text(user_prompt)
            parsed = self._fallback_parse(text)

        doc = GeneratedDocument(
            file_path=analysis.file_path.replace(".py", "_DOC.md").replace(".sql", "_DOC.md"),
            script_path=analysis.file_path,
            business_intent=parsed.get("business_intent", ""),
            input_output_spec=parsed.get("input_output_spec", ""),
            key_functions=parsed.get("key_functions", []),
            boundary_conditions=[
                BoundaryCondition(**bc) for bc in parsed.get("boundary_conditions", [])
            ],
            uncertainty_checklist=[
                UncertaintyItem(**ui) for ui in parsed.get("uncertainty_checklist", [])
            ],
            sections=[
                DocSection(**sec) for sec in parsed.get("sections", [])
            ],
            overall_confidence=self.assess_confidence(str(parsed)),
            needs_human_review=False,
        )

        # Apply confidence threshold for human-review flagging
        doc.needs_human_review = doc.overall_confidence < self.low_confidence_threshold
        if doc.uncertainty_checklist:
            low_conf_items = [
                u for u in doc.uncertainty_checklist if u.confidence < self.low_confidence_threshold
            ]
            if low_conf_items:
                doc.needs_human_review = True

        doc.markdown_body = self._render_markdown(doc)
        self._metrics["overall_confidence"] = doc.overall_confidence
        self._metrics["needs_human_review"] = doc.needs_human_review
        return doc

    # ------------------------------------------------------------------
    def _build_prompt(self, analysis: ScriptAnalysis, source: str) -> str:
        return f"""Generate comprehensive Markdown documentation for the following legacy script.

## Script path
{analysis.file_path}

## Static analysis results
- Functions: {analysis.ast.functions}
- Imports: {analysis.ast.imports}
- Input tables: {analysis.data_deps.input_tables}
- Output tables: {analysis.data_deps.output_tables}
- SQL patterns: {[p.value for p in analysis.data_deps.sql_patterns_detected]}
- External calls: {[(c.name, c.call_type) for c in analysis.external_calls]}
- Control-flow complexity: {analysis.ast.control_flow_complexity}

## Data dependency graph (Mermaid)
{analysis.data_deps.mermaid_diagram or '(not available)'}

## Source code (first 6000 chars)
```python
{source[:6000]}
```

## Required JSON schema
{{
  "business_intent": "<1–3 sentence summary of what this script does and why>",
  "input_output_spec": "<Markdown table describing inputs and outputs>",
  "key_functions": [{{"name": "...", "role": "...", "side_effects": "..."}}],
  "boundary_conditions": [{{"condition": "...", "expected_behavior": "...", "severity": "low|medium|high|critical"}}],
  "uncertainty_checklist": [{{"category": "data_caliber|business_rule|system_dependency|other", "description": "...", "context_snippet": "...", "suggested_resolution": "...", "confidence": 0.0}}],
  "sections": [{{"title": "...", "content": "<Markdown body>", "level": 2}}]
}}"""

    # ------------------------------------------------------------------
    @staticmethod
    def _render_markdown(doc: GeneratedDocument) -> str:
        lines = [
            f"# Script Documentation: `{doc.script_path}`",
            "",
            "> **Overall confidence:** {:.0%}  ".format(doc.overall_confidence),
            f"> **Needs human review:** {'YES' if doc.needs_human_review else 'No'}",
            "",
            "## Business Intent",
            "",
            doc.business_intent,
            "",
            "## Input / Output Specification",
            "",
            doc.input_output_spec,
            "",
        ]
        for sec in doc.sections:
            lines.append(f"{'#' * sec.level} {sec.title}")
            lines.append("")
            lines.append(sec.content)
            lines.append("")

        if doc.key_functions:
            lines.append("## Key Functions")
            lines.append("")
            lines.append("| Function | Role | Side Effects |")
            lines.append("|----------|------|-------------|")
            for fn in doc.key_functions:
                lines.append(
                    f"| `{fn.get('name', '?')}` | {fn.get('role', '?')} | {fn.get('side_effects', '—')} |"
                )
            lines.append("")

        if doc.boundary_conditions:
            lines.append("## Boundary Conditions")
            lines.append("")
            lines.append("| Condition | Expected Behavior | Severity |")
            lines.append("|-----------|------------------|----------|")
            for bc in doc.boundary_conditions:
                lines.append(
                    f"| {bc.condition} | {bc.expected_behavior} | `{bc.severity}` |"
                )
            lines.append("")

        if doc.uncertainty_checklist:
            lines.append("## Uncertainty Checklist")
            lines.append("")
            for item in doc.uncertainty_checklist:
                lines.append(
                    f"- **[{item.category}]** {item.description} (confidence: {item.confidence:.0%})"
                )
                if item.context_snippet:
                    lines.append(f"  - Context: `{item.context_snippet[:200]}`")
                if item.suggested_resolution:
                    lines.append(f"  - Suggestion: {item.suggested_resolution}")
            lines.append("")

        return "\n".join(lines)

    @staticmethod
    def _fallback_parse(text: str) -> dict:
        """Minimal best-effort parse when JSON fails."""
        return {
            "business_intent": text[:500],
            "input_output_spec": "",
            "key_functions": [],
            "boundary_conditions": [],
            "uncertainty_checklist": [
                {
                    "category": "other",
                    "description": "LLM output was not valid JSON",
                    "context_snippet": text[:200],
                    "suggested_resolution": "Re-run analysis or manually review",
                    "confidence": 0.1,
                }
            ],
            "sections": [],
        }
