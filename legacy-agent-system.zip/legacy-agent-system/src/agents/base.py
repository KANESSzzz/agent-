"""Base agent with shared LLM client, logging, and confidence assessment."""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from typing import Any, Optional

from ..utils.llm_client import LLMClient, ModelRouter
from ..utils.logger import get_logger


class BaseAgent(ABC):
    """Abstract agent that other agents inherit from.

    Each subclass overrides:
      - agent_name
      - system_prompt
      - execute(script_source, **kwargs) → result dataclass
    """

    agent_name: str = "base"
    low_confidence_threshold: float = 0.70

    def __init__(self, llm: Optional[LLMClient] = None):
        self.llm = llm or LLMClient()
        self.logger = get_logger(f"agent.{self.agent_name}")
        self._metrics: dict[str, Any] = {}

    @property
    @abstractmethod
    def system_prompt(self) -> str:
        ...

    @abstractmethod
    def execute(self, source: str, file_path: str = "", **kwargs: Any) -> Any:
        ...

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------
    def _reasoning_call(
        self, user_prompt: str, max_tokens: int = 8000
    ) -> tuple[str, int, int]:
        """Route to Claude for long-chain reasoning."""
        return self.llm.claude_complete(
            system_prompt=self.system_prompt,
            user_prompt=user_prompt,
            max_tokens=max_tokens,
        )

    def _structured_json(self, user_prompt: str) -> dict:
        """Route to DeepSeek for structured JSON output."""
        return self.llm.deepseek_json(
            system_prompt=self.system_prompt, user_prompt=user_prompt
        )

    def _structured_text(self, user_prompt: str, max_tokens: int = 4096) -> str:
        """Route to DeepSeek for structured text output."""
        text, _, _ = self.llm.deepseek_complete(
            system_prompt=self.system_prompt,
            user_prompt=user_prompt,
            max_tokens=max_tokens,
        )
        return text

    # ------------------------------------------------------------------
    # Confidence & metrics
    # ------------------------------------------------------------------
    def assess_confidence(self, response_text: str) -> float:
        """Heuristic confidence score based on response quality signals."""
        score = 0.5
        # Longer, well-structured responses → higher confidence
        if len(response_text) > 2000:
            score += 0.10
        if "```" in response_text:
            score += 0.05
        # Missing sections or explicit disclaimers → lower
        uncertainty_markers = {
            "i am not sure": -0.10,
            "cannot determine": -0.15,
            "unsure": -0.10,
            "unclear": -0.08,
            "needs human": -0.15,
            "insufficient information": -0.12,
        }
        lower = response_text.lower()
        for marker, penalty in uncertainty_markers.items():
            if marker in lower:
                score += penalty
        return max(0.0, min(1.0, score))

    @property
    def metrics(self) -> dict:
        return self._metrics

    def _record_metric(self, key: str, value: Any) -> None:
        self._metrics[key] = value
