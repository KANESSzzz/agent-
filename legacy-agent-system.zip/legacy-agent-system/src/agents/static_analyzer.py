"""Static Analysis Agent — AST, data dependency graph, external system calls.

Uses Claude (long-chain reasoning, max_tokens=8000) to deeply analyze
legacy Python/SQL scripts. Handles SQL string concatenation patterns and
dynamic table name recognition.
"""

from __future__ import annotations

import json
import time
from typing import Optional

from ..models.script_analysis import (
    ASTDescriptor,
    DataDependencyGraph,
    ExternalCall,
    ScriptAnalysis,
    SQLPattern,
)
from ..utils.sql_parser import SQLParser
from .base import BaseAgent


class StaticAnalyzerAgent(BaseAgent):
    """Generates AST descriptions + data dependency graphs + external call chains."""

    agent_name = "static_analyzer"

    @property
    def system_prompt(self) -> str:
        return (
            "You are an expert static code analyzer specializing in legacy Python data-processing scripts. "
            "Your task is to produce a detailed JSON analysis containing:\n"
            "1. A structured AST summary (functions, imports, classes, globals, decorators, control-flow complexity).\n"
            "2. A data-dependency graph: input/output tables, intermediate views, SQL patterns, dynamic table references.\n"
            "3. External system calls: databases, APIs, file I/O, environment variables, subprocess invocations.\n"
            "For each external call, identify the call type, parameter list, and whether it is dynamically constructed.\n"
            "Flag any SQL string concatenation (f-strings, + operator, %%s-formatting) as a security and maintainability risk.\n"
            "Provide a Mermaid diagram definition for the data dependency graph.\n"
            "Output ONLY valid JSON — no markdown fences, no commentary."
        )

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------
    def execute(
        self, source: str, file_path: str = "", **kwargs
    ) -> ScriptAnalysis:
        start = time.perf_counter()
        self.logger.info("Analyzing %s (%d LOC)", file_path or "<source>", len(source.splitlines()))

        # Phase 1: Local SQL pattern detection (fast, no LLM)
        sql_extractions = SQLParser.extract_sql_strings(source)
        dynamic_tables = SQLParser.detect_dynamic_tables(source)

        # Phase 2: Deep LLM analysis via Claude
        user_prompt = self._build_prompt(source, file_path, sql_extractions)
        raw_json, in_tok, out_tok = self._reasoning_call(user_prompt, max_tokens=8000)
        parsed = self._parse_response(raw_json)

        # Phase 3: Merge local detections into LLM output
        self._enrich_with_local_findings(parsed, sql_extractions, dynamic_tables)

        # Phase 4: Build the analysis object
        analysis = ScriptAnalysis(
            file_path=file_path,
            ast=ASTDescriptor(
                functions=parsed.get("functions", []),
                imports=parsed.get("imports", []),
                classes=parsed.get("classes", []),
                global_vars=parsed.get("global_vars", []),
                decorators=parsed.get("decorators", []),
                control_flow_complexity=parsed.get("control_flow_complexity", 0),
                raw_ast_json=json.dumps(parsed.get("ast_detail", {})),
            ),
            data_deps=DataDependencyGraph(
                nodes=parsed.get("ddg_nodes", []),
                edges=parsed.get("ddg_edges", []),
                input_tables=parsed.get("input_tables", []),
                output_tables=parsed.get("output_tables", []),
                intermediate_views=parsed.get("intermediate_views", []),
                sql_patterns_detected=self._classify_patterns(sql_extractions),
                dynamic_table_references=list(dynamic_tables),
                mermaid_diagram=parsed.get("mermaid_diagram"),
            ),
            external_calls=[
                ExternalCall(**ec) for ec in parsed.get("external_calls", [])
            ],
            estimated_loc=len(source.splitlines()),
            language="python" if file_path.endswith(".py") else "sql",
            raw_prompt_tokens=in_tok,
            raw_completion_tokens=out_tok,
            llm_model_used="claude-3-5-sonnet-20241022",
            analysis_duration_ms=(time.perf_counter() - start) * 1000,
        )
        self._metrics["duration_ms"] = analysis.analysis_duration_ms
        return analysis

    # ------------------------------------------------------------------
    # Prompt construction
    # ------------------------------------------------------------------
    def _build_prompt(
        self, source: str, file_path: str, sql_exts: list
    ) -> str:
        sql_summary = "\n".join(
            f"  - [{e.pattern.value}] {e.raw_sql[:120]}..." for e in sql_exts[:10]
        ) or "  (none detected locally)"
        return f"""Analyze the following legacy Python script and return ONLY a JSON object.

## Script path
{file_path or 'inline'}

## Pre-detected SQL patterns (local parser)
{sql_summary}

## Source code
```python
{source}
```

## Required JSON schema
{{
  "functions": [{{"name": "...", "params": [...], "returns": "...", "docstring": "...", "calls": [...]}}],
  "imports": ["..."],
  "classes": [{{"name": "...", "methods": [...]}}],
  "global_vars": ["..."],
  "decorators": ["..."],
  "control_flow_complexity": <int>,
  "ast_detail": {{}},
  "ddg_nodes": [{{"id": "...", "label": "...", "type": "table|view|transform"}}],
  "ddg_edges": [{{"from": "...", "to": "...", "label": "..."}}],
  "input_tables": ["..."],
  "output_tables": ["..."],
  "intermediate_views": ["..."],
  "dynamic_table_references": ["..."],
  "mermaid_diagram": "graph TD\\n  ...",
  "external_calls": [{{"name": "...", "call_type": "database|api|file_io|env|subprocess", "pattern": "...", "parameters": [...], "is_dynamic": false}}]
}}"""

    # ------------------------------------------------------------------
    # Response parsing
    # ------------------------------------------------------------------
    @staticmethod
    def _parse_response(raw: str) -> dict:
        """Extract JSON from LLM response, handling markdown fences."""
        text = raw.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1]
            if text.endswith("```"):
                text = text[:-3]
            text = text.strip()
        # Some models prefix with "json" after the opening fence
        if text.startswith("json\n"):
            text = text[5:].strip()
        return json.loads(text)

    # ------------------------------------------------------------------
    # Enrichment
    # ------------------------------------------------------------------
    @staticmethod
    def _enrich_with_local_findings(
        parsed: dict,
        sql_extractions: list,
        dynamic_tables: list[str],
    ) -> None:
        """Merge locally-detected patterns into the LLM analysis."""
        existing_tables = set(parsed.get("input_tables", []))
        for ext in sql_extractions:
            for tbl in ext.tables_referenced:
                if tbl not in existing_tables:
                    parsed.setdefault("input_tables", []).append(tbl)
        existing_dynamic = set(parsed.get("dynamic_table_references", []))
        for tbl in dynamic_tables:
            if tbl not in existing_dynamic:
                parsed.setdefault("dynamic_table_references", []).append(tbl)

    @staticmethod
    def _classify_patterns(sql_extractions: list) -> list[SQLPattern]:
        seen = set()
        result = []
        for ext in sql_extractions:
            if ext.pattern not in seen:
                seen.add(ext.pattern)
                result.append(ext.pattern)
        return result or [SQLPattern.UNKNOWN]
