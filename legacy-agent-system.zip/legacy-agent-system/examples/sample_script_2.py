"""Legacy data quality checker — validates merchant transaction reports.

Written ~2018. Heavily relies on stored procedures and dynamic SQL construction.
Multiple hard-coded thresholds that nobody remembers the rationale for.
"""

import json
import os
from datetime import datetime
from typing import Any

import pymysql

DB_CONFIG = {
    "host": os.getenv("TRANS_DB_HOST", "mysql.transactions.internal"),
    "user": os.getenv("TRANS_DB_USER", "dq_checker"),
    "password": os.getenv("TRANS_DB_PASS", ""),
    "database": "transactions",
}


def get_connection():
    return pymysql.connect(**DB_CONFIG, cursorclass=pymysql.cursors.DictCursor)


# ── Threshold constants (origin unknown) ─────────────────────────

MAX_TRANSACTION_AMOUNT = 50000         # flag > $50K
MIN_TRANSACTION_AMOUNT = 0.01           # ignore sub-cent
SUSPICIOUS_HOURS = [2, 3, 4]            # 2-4 AM flagged
MERCHANT_BLACKLIST = ["MERC_0888", "MERC_0999", "MERC_0777"]

# Dynamic table — changes per quarter based on fiscal calendar
FISCAL_TABLE = "transactions_q1_2024"


def check_amount_anomalies(cursor, table: str) -> list[dict]:
    """Flag transactions exceeding the max threshold."""
    sql = (
        "SELECT txn_id, merchant_id, amount, txn_time "
        f"FROM {table} "
        f"WHERE amount > {MAX_TRANSACTION_AMOUNT} "
        "ORDER BY amount DESC"
    )
    cursor.execute(sql)
    return cursor.fetchall()


def check_suspicious_timing(cursor, table: str) -> list[dict]:
    """Flag transactions at unusual hours."""
    hour_list = ", ".join(str(h) for h in SUSPICIOUS_HOURS)
    sql = (
        f"SELECT txn_id, merchant_id, amount, HOUR(txn_time) as hour "
        f"FROM {table} "
        f"WHERE HOUR(txn_time) IN ({hour_list}) "
        f"  AND amount > {MIN_TRANSACTION_AMOUNT}"
    )
    cursor.execute(sql)
    return cursor.fetchall()


def check_blacklisted_merchants(cursor, table: str) -> list[dict]:
    """Check for transactions from blacklisted merchants."""
    if not MERCHANT_BLACKLIST:
        return []
    placeholders = ", ".join(f"'{m}'" for m in MERCHANT_BLACKLIST)
    sql = (
        f"SELECT txn_id, merchant_id, amount, txn_time "
        f"FROM {table} "
        f"WHERE merchant_id IN ({placeholders})"
    )
    cursor.execute(sql)
    return cursor.fetchall()


def build_report(anomalies: list, suspicious: list, blacklisted: list) -> dict[str, Any]:
    """Aggregate findings into a JSON-serializable report."""
    return {
        "generated_at": datetime.now().isoformat(),
        "table_checked": FISCAL_TABLE,
        "summary": {
            "amount_anomalies": len(anomalies),
            "suspicious_timing": len(suspicious),
            "blacklisted_merchants": len(blacklisted),
        },
        "details": {
            "amount_anomalies": anomalies[:100],      # truncate for report
            "suspicious_timing": suspicious[:100],
            "blacklisted_merchants": blacklisted[:100],
        },
    }


def main():
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            anomalies = check_amount_anomalies(cur, FISCAL_TABLE)
            suspicious = check_suspicious_timing(cur, FISCAL_TABLE)
            blacklisted = check_blacklisted_merchants(cur, FISCAL_TABLE)
        report = build_report(anomalies, suspicious, blacklisted)
        print(json.dumps(report, indent=2, default=str))
        return report
    finally:
        conn.close()


if __name__ == "__main__":
    main()
