"""Legacy ETL script — daily user activity aggregation.

Written ~2019 by former team member. No tests, no docs.
Reads from MySQL, transforms with pandas, writes to PostgreSQL analytics DB.
"""

import os
import logging
from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import create_engine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database connections (hard-coded in legacy style)
SRC_HOST = os.getenv("MYSQL_HOST", "mysql.internal")
SRC_PORT = os.getenv("MYSQL_PORT", "3306")
DST_HOST = os.getenv("PG_HOST", "postgres.internal")
DST_PORT = os.getenv("PG_PORT", "5432")

TABLE_PREFIX = "user_events"


def get_source_engine():
    user = os.getenv("MYSQL_USER", "etl_reader")
    pwd = os.getenv("MYSQL_PASS", "")
    return create_engine(f"mysql+pymysql://{user}:{pwd}@{SRC_HOST}:{SRC_PORT}/analytics")


def get_dest_engine():
    user = os.getenv("PG_USER", "etl_writer")
    pwd = os.getenv("PG_PASS", "")
    return create_engine(f"postgresql://{user}:{pwd}@{DST_HOST}:{DST_PORT}/analytics_dw")


def fetch_daily_events(date_str: str) -> pd.DataFrame:
    """Query daily user events from the source MySQL DB.

    NOTE: table is sharded by week — table name uses date suffix.
    """
    src = get_source_engine()
    table_name = f"{TABLE_PREFIX}_{date_str[:4]}_w{int(date_str[5:7]) // 4}"
    sql = f"""
        SELECT
            user_id,
            event_type,
            event_payload,
            created_at
        FROM {table_name}
        WHERE DATE(created_at) = '{date_str}'
          AND event_type IN ('click', 'view', 'purchase', 'share')
    """
    logger.info("Fetching from table: %s", table_name)
    df = pd.read_sql(sql, src)
    src.dispose()
    return df


def transform_events(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate events per user per event type."""
    if df.empty:
        return pd.DataFrame(columns=["user_id", "event_type", "count", "report_date"])

    df["report_date"] = pd.to_datetime(df["created_at"]).dt.date
    agg = (
        df.groupby(["user_id", "event_type", "report_date"])
        .size()
        .reset_index(name="count")
    )
    # Add derived metrics
    agg["is_high_value"] = agg["count"] > 10
    agg["score"] = agg["count"] * agg["event_type"].map(
        {"purchase": 10, "share": 5, "click": 1, "view": 0.5}
    )
    return agg


def load_to_dw(df: pd.DataFrame, date_str: str):
    """Upsert aggregated data into the data warehouse."""
    if df.empty:
        logger.warning("No data to load for %s", date_str)
        return
    dst = get_dest_engine()
    with dst.begin() as conn:
        # Delete existing rows for this date
        conn.execute(
            f"DELETE FROM dw.daily_user_activity WHERE report_date = '{date_str}'"
        )
        df.to_sql(
            "daily_user_activity",
            conn,
            schema="dw",
            if_exists="append",
            index=False,
            method="multi",
        )
    dst.dispose()
    logger.info("Loaded %d rows into dw.daily_user_activity", len(df))


def main(date_str: str | None = None):
    if date_str is None:
        date_str = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    logger.info("Starting ETL for %s", date_str)
    raw = fetch_daily_events(date_str)
    transformed = transform_events(raw)
    load_to_dw(transformed, date_str)
    logger.info("ETL complete for %s — processed %d raw events", date_str, len(raw))
    return transformed


if __name__ == "__main__":
    main()
